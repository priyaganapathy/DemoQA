module.exports = class Page {
    open(path) {
        browser.url(path)
    }
    }