const Page = require('./page')
class StudentPage extends Page{
    
    open() {
    super.open('https://demoqa.com/automation-practice-form');
    }
    //Scenario 1 elements
    async firstName() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[1]/div[2]/input')}
    async lastName() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[1]/div[4]/input')}
    async email() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[2]/div[2]/input')}
    async gender() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[3]/div[2]/div[2]/label')}
    async mobileNumber() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[4]/div[2]/input')}
    async calendar() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[1]/div/input')}
    async calendarYear() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select')}
    async dobYear() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select/option[106]')}
    async dobDate(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[2]/div[2]/div/div/div[2]/div[2]/div[3]/div[2]')}
    async Subjects() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[6]/div[2]/div/div')}
    async Hobbies() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[7]/div[2]/div[3]/label')}
    async picture() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[8]/div[2]/div/input')}
    async currentAddress() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[9]/div[2]/textarea')}
    async state() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[2]/div/div/div[1]/div[1]')}
    async stateName(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[2]/div/div/div[1]/div[1]')}
    async city() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[3]/div/div/div[1]/div[2]')}
    async cityName() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[3]/div/div/div[1]/div[1]')}
    async submit() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[11]/div/button')}
    async submitForm(){return await browser.$('/html/body/div[3]/div/div/div[1]/div')};
    async close(){return await browser.$('/html/body/div[3]/div/div/div[3]/button')};
    
    //Scenario 2 Elements
    async alertHeader(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[3]/span/div/div[1]')};
    async alertOption(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[3]/div/ul/li[2]/span')};
    async clickMe(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[2]/div[2]/button')};
    
    //Scenario 3 Elements
    async widgets(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[4]/span/div')};
    async toolTips(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[4]/div/ul/li[7]/span')};
    
        
    async selectName(fname,lname){
        var fnameEle = await this.firstName();
        await fnameEle.setValue(fname);
        var lnameEle = await this.lastName();
        await lnameEle.setValue(lname);    
    }
    async selectEmail(emailID){
        var emailEle = await this.email();
        await emailEle.setValue(emailID);
    }
    async selectGender(){
        var genderEle = await this.gender();
        await genderEle.click();
    }
    async selectMobileNo(mNumber){
        var mobileEle = await this.mobileNumber();
        await mobileEle.setValue(mNumber);
    }
    async selectDOB(){
        var calenderEle = await this.calendar();
        await calenderEle.click();
        var dobYearEle = await this.dobYear();
        await dobYearEle.click();
        var dobDateEle = await this.dobDate();
        await dobDateEle.click();
     }
    async selectSubject(sub){
        var subEle = await this.Subjects();
        await subEle.setValue(sub);
    }
    async selectHobbies(){
        var hobbyEle =await this.Hobbies();
        await hobbyEle.click();
    }
    async selectAddress(addr){
        var currAddrEle = await this.currentAddress();
        await currAddrEle.setValue(addr);
    }
    async selectStateCity(){
        var stateEle = await this.state();
        await stateEle.click();
        var stateNameEle = await this.stateName();
        await stateNameEle.click();
        var cityEle = await this.city();
        await cityEle.click();
        var cityNameEle = await this.cityName();
        await cityNameEle.click();
    }
    async selectSubmit(){
        var submitEle=await this.submit();
        await submitEle.click();
    }
    async isStudentFormSubmitted(){
        var filchardetailsEle = await this.submitForm();
        var isVisibleOnUI = await filchardetailsEle.isDisplayed();
        return isVisibleOnUI;
    }
    async selectClose(){
        var closeEle=await this.close();
        await closeEle.click();
    }
    async selectAlert(){
        var alertHeaderEle =await this.alertHeader();
        await alertHeaderEle.click();
        var alertOptionEle =await this.alertOption();
        await alertOptionEle.click();
        var alertFiveSecEle =await this.clickMe();
        await alertFiveSecEle.click();
    }
    async selectwidgets(){
        var widgesEle=await this.widgets();
        await widgesEle.click();
    }
    async selectToolTips(){
        var tooltipsEle=await this.toolTips();
        await tooltipsEle.click();
    }
    async selectHover(){
    var hoverToSeeBtn= await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[1]/button');
    var hoverToSeeText=await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[2]/input');
    browser.elementHover("hoverToSeeBtn");
    await hoverToSeeBtn.click();
    browser.elementHover("hoverToSeeText");
    await hoverToSeeText.click();
    await browser.pause(2000);
    }
}
module.exports = new StudentPage();