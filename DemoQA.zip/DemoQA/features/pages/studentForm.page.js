const Page = require('./page')
class StudentPage extends Page{
    
    open() {
    super.open('https://demoqa.com/automation-practice-form');
    }
    //Scenario 1 elements
    async firstName() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[1]/div[2]/input')}
    async lastName() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[1]/div[4]/input')}
    async email() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[2]/div[2]/input')}
    async gender() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[3]/div[2]/div[2]/label')}
    async mobileNumber() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[4]/div[2]/input')}
    async calendar() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[1]/div/input')}
    async calendarYear() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select')}
    async dobYear() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select/option[106]')}
    async dobDate(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[5]/div[2]/div[2]/div[2]/div/div/div[2]/div[2]/div[3]/div[2]')}
    async Subjects() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[6]/div[2]/div/div')}
    async Hobbies() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[7]/div[2]/div[3]/label')}
    async picture() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[8]/div[2]/div/input')}
    async currentAddress() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[9]/div[2]/textarea')}
    async state() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[2]/div/div/div[1]/div[1]')}
    async stateName(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[2]/div/div/div[1]/div[1]')}
    async city() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[3]/div/div/div[1]/div[2]')}
    async cityName() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[3]/div/div/div[1]/div[1]')}
    async submit() {return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[11]/div/button')}
    async submitForm(){return await browser.$('/html/body/div[3]/div/div/div[1]/div')};
    async close(){return await browser.$('/html/body/div[3]/div/div/div[3]/button')};
    
    //Scenario 2 Elements
    async alertHeader(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[3]/span/div/div[1]')};
    async alertOption(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[3]/div/ul/li[2]/span')};
    async clickMe(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[2]/div[2]/button')};
    async modalDialogs(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[3]/div/ul/li[5]/span')};
    async smallModal(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div/button[1]')};
    async smallModalClose(){return await browser.$('/html/body/div[3]/div/div/div[3]/button')};
    
    //Scenario 3 Elements
    async widgets(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[4]/span/div')};
    async toolTips(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[4]/div/ul/li[7]/span')};
    async hoverToSeeBtn(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[1]/button')};
    async hoverToSeeText(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[2]/input')};
    async datePicker(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[4]/div/ul/li[3]/span')};
    async selectDate(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[1]/div[2]/div/div/input')};
    async dateAndTime(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[1]/div/input')};
    async nextMonth(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div[2]/div/div/button[2]')};

    //Scenario 4 elements
    async dragme(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div/div[1]/div/div[1]')};
    async drophere(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div/div[1]/div/div[2]')};
    async interactions(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[5]/span/div/div[1]')};
    async droppable(){return await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[5]/div/ul/li[4]/span')};
    async dropped(){return await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/div/div[1]/div/div[2]/p')};

    async selectName(fname,lname){
        var fnameEle = await this.firstName();
        await fnameEle.setValue(fname);
        var lnameEle = await this.lastName();
        await lnameEle.setValue(lname);    
    }
    async selectEmail(emailID){
        var emailEle = await this.email();
        await emailEle.setValue(emailID);
    }
    async selectGender(){
        var genderEle = await this.gender();
        await genderEle.click();
    }
    async selectMobileNo(mNumber){
        var mobileEle = await this.mobileNumber();
        await mobileEle.setValue(mNumber);
    }
    async selectDOB(){
        var calenderEle = await this.calendar();
        await calenderEle.click();
        var dobYearEle = await this.dobYear();
        await dobYearEle.click();
        var dobDateEle = await this.dobDate();
        await dobDateEle.click();
     }
    async selectSubject(sub){
        var subEle = await this.Subjects();
        await subEle.setValue(sub);
    }
    async selectHobbies(){
        var hobbyEle =await this.Hobbies();
        await hobbyEle.click();
    }
    async selectAddress(addr){
        var currAddrEle = await this.currentAddress();
        await currAddrEle.setValue(addr);
    }
    async selectStateCity(){
        var stateEle = await this.state();
        await stateEle.click();
        var stateNameEle = await this.stateName();
        await stateNameEle.click();
        var cityEle = await this.city();
        await cityEle.click();
        var cityNameEle = await this.cityName();
        await cityNameEle.click();
    }
    async selectSubmit(){
        var submitEle=await this.submit();
        await submitEle.click();
    }
    async isStudentFormSubmitted(){
        var filchardetailsEle = await this.submitForm();
        var isVisibleOnUI = await filchardetailsEle.isDisplayed();
        return isVisibleOnUI;
    }
    async selectClose(){
        var closeEle=await this.close();
        await closeEle.click();
    }
    async selectAlert(){
        var alertHeaderEle =await this.alertHeader();
        await alertHeaderEle.click();
        var alertOptionEle =await this.alertOption();
        await alertOptionEle.click();
        var alertFiveSecEle =await this.clickMe();
        await alertFiveSecEle.click();
    }
    async selectModal(){
        var modalDialogsEle=await this.modalDialogs();
        await modalDialogsEle.scrollIntoView(7000);
        await modalDialogsEle.click();
    }
    async selectSmallModal(){
        var smallModalEle=await this.smallModal();
        await smallModalEle.scrollIntoView(7000);
        await smallModalEle.click();
    }
    async isSmallModalDisplayed(){
        var smallModalWindowEle = await this.smallModalClose();
        var isVisibleOnUI = await smallModalWindowEle.isDisplayed();
        return isVisibleOnUI;
    }
    async selectSmallModalClose(){
        var smallModalCloseEle=await this.smallModalClose();
        await smallModalCloseEle.click();
    }
    async selectwidgets(){
        var widgesEle=await this.widgets();
        await widgesEle.click();
    }
    async selectToolTips(){
        var tooltipsEle=await this.toolTips();
        await tooltipsEle.click();
    }
    async selectHover(){
        var hoverToSeeBtnEle= await this.hoverToSeeBtn();
        var hoverToSeeTextEle=await this.hoverToSeeText();
        browser.elementHover("hoverToSeeBtnEle");
        await hoverToSeeBtnEle.click();
        browser.elementHover("hoverToSeeTextEle");
        await hoverToSeeTextEle.click();
        await browser.pause(2000);
    }
    async selectInteractions(){

        var interactionEle=await this.interactions();
        await interactionEle.scrollIntoView(6000);
        await interactionEle.click();
    }
    async selectDroppable(){
        var droppableEle=await this.droppable();
        await droppableEle.scrollIntoView(6000);
        await droppableEle.click();
    }
    async selectDragMe(){
        var dragMeEle=await this.dragme();
        var dropHereEle=await this.drophere();
        await dropHereEle.scrollIntoView(9000);
        dragMeEle.dragAndDrop(dropHereEle,2000);
        //var actionEle = actions.dragAndDrop(dragMeEle, dropHereEle).perform();
    }
    async isDropped(){
        var droppedEle = await this.dropped();
        var isVisibleOnUI = await droppedEle.isDisplayed();
        return isVisibleOnUI;

    }
    async selectDatePicker(){
        var datePickerEle=await this.datePicker();
        await datePickerEle.scrollIntoView(6000);
        await datePickerEle.click();
    }
    async selectDatePickerDate(){
        var selectDateEle=await this.selectDate();
        await selectDateEle.scrollIntoView(6000);
        await selectDateEle.click();        
    }
    async selectNextMonth(){
        var nextMonthEle=await this.nextMonth();
        await nextMonthEle.click();
    }
}
module.exports = new StudentPage();