const StudentPage = require('../pages/studentForm.page')
const { Given, When, Then } = require('cucumber')
const assert = require('assert');
const path = require('path');
const { picture } = require('../pages/studentForm.page');
const { Console } = require('console');

Given('I am on demoqa students form page', async function () {

await StudentPage.open();
await browser.pause(2000)
var size = await browser.setWindowSize(1300, 840);
console.log(size);
var title = await browser.getTitle();
console.log(title);
assert.deepStrictEqual("ToolsQA", title)
});

When('I enter FirstName as {string} and LastName as {string}', async function (fname, lname) {
    await StudentPage.selectName(fname,lname);
    await browser.pause(2000)
});
When('I enter Email as {string}', async function (emailID) {
    await StudentPage.selectEmail(emailID);
    await browser.pause(2000)
});
When ('I click on Gender',async function(){
    await StudentPage.selectGender();
await browser.pause(4000)
})
When('I enter MobileNumber as {string}', async function (mNumber) {
    await StudentPage.selectMobileNo(mNumber);
    await browser.pause(2000)         
});
When('I choose DateOfBirth from calendar', async function () {
    await StudentPage.selectDOB();
    await browser.pause(4000)
});
When('I select Hobbies', async function () {
    await StudentPage.selectHobbies();
    await browser.pause(2000);
});
When('I attach a Picture', async function () {
        var picture = await browser.$('/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[8]/div[2]/div/input')
        await picture.scrollIntoView(7000);
        await browser.pause(4000)
        var filePath = path.join(__dirname,'backgrounds.jpg');
        await browser.pause(4000)
        var remoteFilePath = await browser.uploadFile(filePath);
        await picture.setValue(remoteFilePath); 
        await browser.pause(4000)
});
When('I give CurrentAddress as {string}', async function (addr) {
    await StudentPage.selectAddress(addr);
    await browser.pause(2000);
});
When('I click on Submit button', async function () {
    await StudentPage.selectSubmit();
    await browser.pause(2000);
});
Then('I confirm Student registration form submitted', async function () {
    var isVisible = await StudentPage.isStudentFormSubmitted();
    assert.strictEqual(true, isVisible);
    var submitForm=await browser.$('/html/body/div[3]/div/div/div[1]/div');
    await submitForm.scrollIntoView(7000);
    await StudentPage.selectClose();
    await browser.pause(4000);
});

Given('I am on ToolsQA Alerts page', async function () {
    var title = await browser.getTitle();
    console.log(title);
});
    
When('I select Alert after five seconds', async function () {
    var alertHead=await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[3]/span/div/div[1]');
    await alertHead.scrollIntoView(7000);
    await StudentPage.selectAlert();
    await browser.pause(7000);
});
    
Then('Alert set confirmation popup should appear after five seconds', async function () {
    browser.acceptAlert();
    console.log('Accept Alert Asserted');
    });

    When('I select Dialog Modal', async function () {
    await StudentPage.selectModal();
    await browser.pause(3000);
    });
    
    When('I click on Small Modal', async function () {
        await StudentPage.selectSmallModal();
        await browser.pause(3000);
      });
      Then('I should see Small Modal window', async function () {
        var isVisible = await StudentPage.isSmallModalDisplayed();
    assert.strictEqual(true, isVisible);
      });
      Then('I close small Modal', async function () {
        await StudentPage.selectSmallModalClose();
        await browser.pause(2000);
      });

Given('I select Widgets', async function(){
    var alertHead=await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[3]/span/div/div[1]');
    await alertHead.click();
    await StudentPage.selectwidgets();
    await browser.pause(2000);
});
When ('I click on Tooltips',async function(){
    var alertHead=await browser.$('/html/body/div/div/div/div[2]/div[1]/div/div/div[3]/span/div/div[1]');
    await alertHead.scrollIntoView(9000);
    await StudentPage.selectToolTips();
    await browser.pause(2000);
});
Then('I hover over hoverbutton and hovertextbox', async function(){
    await StudentPage.selectHover();
    await browser.pause(2000);
});
Given('I am on droppable page', async function () {
    await StudentPage.selectwidgets();
    await browser.pause(2000);
    await StudentPage.selectInteractions();
    await browser.pause(2000);
    await StudentPage.selectDroppable();
    await browser.pause(2000);
});
When('I enter select drag me and drop in drop here', async function () {
    await StudentPage.selectDragMe();
    await browser.pause(2000);
});
Then('I should see dropped in drag here box', async function () {
    var isVisible = await StudentPage.isDropped();
    assert.strictEqual(true, isVisible);
});
When('I click on Date picker page', async function () {
    await StudentPage.selectDatePicker();
    await browser.pause(2000);
});
When('I click on Select Date', async function () {
    await StudentPage.selectDatePickerDate();
    await browser.pause(2000);
    await StudentPage.selectNextMonth();
    await browser.pause(2000);
       
});
Then('I add one month from todays date', async function () {
    var mon = new Date();
    mon.setMonth(mon.getMonth()+1, 1);
    //var da = new Date();
    mon.setDate(mon.getDate(), 1);
    console.log("The new set date is :", mon);
    await browser.pause(2000);
});

